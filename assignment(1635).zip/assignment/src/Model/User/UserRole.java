package Model.User;

public enum UserRole {
    STUDENT, STAFF, CAMP_COMMITTEE
}
