package Model.User;

public enum UserGroup {
    ALL,

    SCSE,

    EEE,

    MAE,

    MSE,

    SPMS,

    ADM,

    SBS,

    NBS,

    ASE,

    SSS,

    WKWSCI,

    CEE,

    NIE,



}
