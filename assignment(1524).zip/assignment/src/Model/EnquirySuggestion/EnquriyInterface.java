package Model.EnquirySuggestion;

public interface EnquriyInterface {
    void printEnquiryDetails(Enquiry enquiry);
}
