package Model.Camp;

public enum CampStatus {
    VISIBLE, HIDDEN
}
