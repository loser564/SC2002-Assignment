package View;

interface MainView {
    public abstract void viewApp(String userID, String password);
    public abstract void printMenu();

    
}
